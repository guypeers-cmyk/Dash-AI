# 🪖 Dash-AI — RAMBO v2.1 Command Center

One self-contained `index.html`. Zero dependencies, zero servers, zero build step.
12 Laws + Protocol v1.4 embedded · 427-agent army · session gate · mission pipeline ·
3D Order of Battle · printable poster · wipe-all privacy lever.

## Deploy (Cloudflare Pages)
- **Direct Upload:** dash.cloudflare.com → Workers & Pages → Create → Pages → Upload assets → drag this folder.
- **From Git:** push this repo, then Pages → Create → Connect to Git → `guypeers-cmyk/Dash-AI` → framework preset **None**, build command *(empty)*, output dir `/`.

## Local
python3 -m http.server 8000 --directory .
